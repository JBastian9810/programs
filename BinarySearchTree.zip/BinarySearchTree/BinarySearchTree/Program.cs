﻿// Jarrett Bastian
// CS_311
// 10/18/2018
// This program creates and upkeeps a binary tree. The user is allowed to insert or delete items at will. 
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BinarySearchTree
{
    class Program
    {
        public class BSTNode // Node class
        {

            public BSTNode leftChild, rightChild;
            public int value;

            public BSTNode(int item) // Constructor
            {
                value = item;
                leftChild = null;
                rightChild = null;
            }

            public BSTNode(int item, BSTNode left, BSTNode right) // Constructor
            {
                value = item;
                leftChild = left;
                rightChild = right;
            }

        }
        public class BinarySearchTree // binary tree class
        {
            public BSTNode root;

            public BSTNode ReturnRoot()
            {
                Console.WriteLine(root); 
                return root; 
            }

            public BinarySearchTree() // Constructor
            {
                root = null; 
            }

            public BinarySearchTree(int rootNode) // Constructor
            {
                root = new BSTNode(rootNode);
            }

            public void Insert(int newNode) // Method that calls InsSearch to search and add new node
            {
                InsSearch(ref root, newNode); 
            }

            public void InputNums(int[] input) // Takes an array and individually adds its elements by calling Insert method
            {
                for (int i = 0; i < input.Length; i++)
                {
                    Insert(input[i]);
                }
            }

            public void InsSearch(ref BSTNode X, int newNode) // Searches for tha appropriate spot for new node
            {
                if (X == null)
                {
                    BSTNode New = new BSTNode(newNode);
                    X = New;
                    InorderTraversal(ref root);
                    Console.WriteLine("");
                    return; 
                }

                if (newNode == X.value)
                {
                    Console.WriteLine("Node already exists...");
                }

                if (newNode < X.value)
                {
                    InsSearch(ref X.leftChild, newNode);
                    return; 
                }

                if (newNode > X.value)
                {
                    InsSearch(ref X.rightChild, newNode);
                    return; 
                }
            }

            public void delSearch(ref BSTNode X, int delNode) // Searches for the desired node to delete and or reorders the tree to upkeep the binary tree order
            {
                if (root == null)
                {
                    Console.WriteLine("There are no nodes to delete..."); 
                }

                if (X == null)
                {
                    Console.WriteLine("Node does not exist...");
                    
                }

                if (delNode < X.value)
                {
                    delSearch(ref X.leftChild, delNode);
                }

                if (delNode > X.value)
                {
                    delSearch(ref X.rightChild, delNode);
                }

                if (delNode == X.value)
                {
                    if (X.leftChild == null && X.rightChild == null)
                    {
                        X = null;
                    }
                    else if (X.leftChild == null)
                    {
                        X.value = X.rightChild.value;
                        X.rightChild = null; 
                    }
                    else if (X.rightChild == null)
                    {
                        X.value = X.leftChild.value;
                        X.leftChild = null; 
                    }
                    else
                    {
                        ReplaceInternal(ref X); 
                    }
                    InorderTraversal(ref root);
                    Console.WriteLine(""); 
                }
            } 
            
            public void ReplaceInternal(ref BSTNode X) // Method that reorders the binary tree to keep order correct. Also deletes desired node.
            {
                if (X.leftChild != null && X.rightChild == null)
                {
                    int temp = 0;
                    temp = X.value;
                    X.value = X.leftChild.value;
                    X.leftChild.value = temp;
                    ReplaceInternal(ref X.leftChild);
                }

                if (X.rightChild != null && X.leftChild == null)
                {
                    int temp = 0;
                    temp = X.value;
                    X.value = X.rightChild.value;
                    X.rightChild.value = temp;
                    ReplaceInternal(ref X.rightChild);
                }

                if (X.rightChild != null && X.leftChild != null)
                {
                    int temp = 0;
                    temp = X.value;
                    X.value = X.rightChild.value;
                    X.rightChild.value = temp;
                    ReplaceInternal(ref X.rightChild);
                }

                if (X.leftChild == null && X.rightChild == null)
                {
                    X = null;
                }
            }
            public void Deletion(int delNode) // Method that calls delSearch so that a node may be taken out of the tree
            {
                delSearch(ref root, delNode); 
            }            

            public void InorderTraversal(ref BSTNode X) // Prints out an inorder traversal of the tree
            {
                if (X.leftChild != null)
                {
                    InorderTraversal(ref X.leftChild); 
                }
                Console.Write(X.value + " "); 
                if (X.rightChild != null)
                {
                    InorderTraversal(ref X.rightChild); 
                }
            }
        }

        static void Main(string[] args)
        {
            bool repeat = true;
            int[] input = { 88, 71, 77, 91, 61, 100, 89, 55 };  
            BinarySearchTree tree = new BinarySearchTree();
            tree.InputNums(input); 
            tree.Deletion(91); 
            tree.Deletion(88);
            tree.Deletion(71); 
            while (repeat == true) // Allows user to insert or delete nodes from console window
            {
                Console.WriteLine("If you would like to insert a number, enter >I<. " +
                "If you would like to delete something, enter >D<. Otherwise, you" +
                "may exit the program.");
                string readS = Console.ReadLine();
                if (readS == "I" || readS == "i")
                {
                    Console.WriteLine("Please type a number for insertion: ");
                    string readI = Console.ReadLine();
                    int readIN = int.Parse(readI);
                    tree.Insert(readIN); 
                }

                else if(readS == "D" || readS == "d")
                {
                    Console.WriteLine("Please type a number for insertion: ");
                    string readD = Console.ReadLine();
                    int readDN = int.Parse(readD);
                    tree.Deletion(readDN);
                }

                else
                {
                    repeat = false; 
                }
            }

        }
    }
}
